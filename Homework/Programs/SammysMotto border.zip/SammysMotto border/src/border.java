import javax.swing.*;

public class border {
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "sSsSsSsSsSsSsSsSsSsSsSsSsSsS\nS Sammy’s makes it fun in the sun  s\n sSsSsSsSsSsSsSsSsSsSsSsSsSsS");
    }
}
