import java.util.Scanner;

public class Eggs
{
    static Integer iDozen, iLoose ;
    static double dozenPrice = 3.25, singlePrice = 0.45, cPrice;
    static Scanner myScanner;
    static  String iString;
    public static void main(String[] args) {
        myScanner = new Scanner(System.in);
        System.out.println("How many dozen do you want?");
        iString = myScanner.nextLine();
        iDozen = Integer.parseInt(iString);
        System.out.println("How many loose eggs do you want?");
        iString = myScanner.nextLine();
        iLoose = Integer.parseInt(iString);
        //Calculate price
        cPrice = ((iDozen * dozenPrice) + (iLoose * singlePrice));
        System.out.println("your price is: " + cPrice);


    }
}
